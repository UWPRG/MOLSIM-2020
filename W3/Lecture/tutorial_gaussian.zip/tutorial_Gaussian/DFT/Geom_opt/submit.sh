#!/bin/bash
# This is an example of basis set projection
#SBATCH --job-name=testing_gaussian
#SBATCH --output=output
#SBATCH --error=error
#SBATCH --time=00:15:00
#SBATCH --mem-per-cpu=4000
#SBATCH --account=davinci
#SBATCH --partition=davinci

#cp * /gscratch/davinci/usr/valleau/tmp/gtmp
#cd /gscratch/davinci/usr/valleau/tmp/gtmp

module load contrib/g16.a03

g16 < gaussian_input 1> h2o.out 2> h2o.err 
