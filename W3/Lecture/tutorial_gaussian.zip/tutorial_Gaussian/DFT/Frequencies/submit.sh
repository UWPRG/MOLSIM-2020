#!/bin/bash
# This is an example of basis set projection
#SBATCH --job-name=testing_gaussian
#SBATCH --output=output
#SBATCH --error=error
#SBATCH --time=00:15:00
#SBATCH --mem-per-cpu=2000
#SBATCH --account=davinci
#SBATCH --partition=davinci


module load contrib/g16.a03

g16 < gaussian_input 1> ch4.out 2> ch4.err 
